// woa, arrowfunction syntax
redir = () => {
    // ;)
    const link = "https://www.youtube.com/watch\?v=dQw4w9WgXcQ"
    window.location.href = link;
}
